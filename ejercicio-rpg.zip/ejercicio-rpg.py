import json
import os

# Datos del jugador
player = {
    "nombre": "",
    "nivel": 1,
    "experiencia": 0,
    "misiones_completadas": 0,
    "meta_diaria": 100
}

def guardar_progreso():
    with open("progreso.json", "w") as f:
        json.dump(player, f)

def cargar_progreso():
    if os.path.exists("progreso.json"):
        with open("progreso.json", "r") as f:
            return json.load(f)
    return player

def mostrar_estado():
    print("\n--- ESTADO DEL HÉROE ---")
    print(f"Nombre: {player['nombre']}")
    print(f"Nivel: {player['nivel']}")
    print(f"Experiencia: {player['experiencia']}")
    print(f"Misiones completadas: {player['misiones_completadas']}")
    print(f"Meta diaria: {player['meta_diaria']} XP\n")

def agregar_experiencia(xp):
    player["experiencia"] += xp
    if player["experiencia"] >= player["nivel"] * 100:
        player["experiencia"] -= player["nivel"] * 100
        player["nivel"] += 1
        print(f"\n🎉 ¡Subiste al nivel {player['nivel']}!\n")

def registrar_mision():
    print("\nElige una misión:")
    print("1. Correr 10 minutos (50 XP)")
    print("2. 20 Flexiones (30 XP)")
    print("3. 30 Sentadillas (40 XP)")
    opcion = input("Selecciona una opción (1-3): ")

    if opcion == "1":
        agregar_experiencia(50)
        player["misiones_completadas"] += 1
    elif opcion == "2":
        agregar_experiencia(30)
        player["misiones_completadas"] += 1
    elif opcion == "3":
        agregar_experiencia(40)
        player["misiones_completadas"] += 1
    else:
        print("Opción no válida.")
    
    guardar_progreso()

def menu():
    while True:
        print("\n--- MENÚ PRINCIPAL ---")
        print("1. Ver estado del héroe")
        print("2. Completar una misión")
        print("3. Salir")

        opcion = input("Selecciona una opción: ")

        if opcion == "1":
            mostrar_estado()
        elif opcion == "2":
            registrar_mision()
        elif opcion == "3":
            print("¡Hasta la próxima, héroe!")
            break
        else:
            print("Opción no válida.")

def main():
    global player
    player = cargar_progreso()

    if not player["nombre"]:
        print("👋 ¡Bienvenido a Ejercicio RPG!")
        nombre = input("Elige el nombre de tu héroe: ")
        player["nombre"] = nombre
        guardar_progreso()
    
    menu()

if __name__ == "__main__":
    main()
